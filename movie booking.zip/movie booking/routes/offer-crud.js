
var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser'); //parses information from POST
router.use(bodyParser.urlencoded({ extended: true }));


var mongoose = require('mongoose');


// var dbHost = 'mongodb://localhost:27017/test';
// mongoose.connect(dbHost);



var offerSchema = mongoose.Schema({
	offerdis:String, 
  offtheatre:String,
  offcity:String

 });
var OFFMODEL = mongoose.model('OFFMODEL', offerSchema, 'offer');


  router.get('/offer', function (req, res) {
    console.log("REACHED GET ID FUNCTION ON SERVER");
     OFFMODEL.find({}, function (err, docs) {
         res.json(docs);
         
    });
});

  router.get('/offer/:id', function (req, res) {
    console.log("REACHED GET ID FUNCTION ON SERVER");
     OFFMODEL.find({_id: req.params.id}, function (err, docs) {
         res.json(docs);
         
    });
});

router.post('/offer', function(req, res){   //inserted to db
  console.log(req.body);
   
  var dis = req.body.offerdis;
  var city=req.body.offcity;
  var theatre = req.body.offtheatre;
  var offobj = new OFFMODEL({
      
    offerdis:dis,
    offcity:city,
    offtheatre:theatre  
  });

  offobj.save(function(err, docs){
    if ( err ) throw err;
    console.log("Book Saved Successfully");
    res.json(docs);
  });

  })

router.delete('/offer/:id', function(req, res){
   console.log("REACHED Delete FUNCTION ON SERVER");
      OFFMODEL.remove({_id:req.params.id}, function(err, docs){
        res.json(docs);
    });
})

router.put('/offer/:id', function(req, res){
    console.log("REACHED PUT");
    console.log(req.body);
    OFFMODEL.findOneAndUpdate({_id:req.params.id}, req.body, function (err, data) {
      res.json(data);
    });
})


// catch 404 and forward to error handler
router.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});


  module.exports = router;