'use strict';


var angular = require('angular');
require('angular-route');
window.$ = window.jQuery = require('jquery');
require('bootstrap');
require('../css/app.scss');

var app = angular.module('movieApp', [ 'ngRoute' ]);

require('./service');
require('./controller');

app.config(function($routeProvider) {

  $routeProvider.when('/home', {
    templateUrl: 'views/home.html',
    controller: 'HomeController',
  })
  .when('/booking', {
    templateUrl: 'views/booking.html',
    controller: 'BookingController',
  })
  .when('/cancellation', {
    templateUrl: 'views/cancellation.html',
    controller: 'CancellationController',
  })
   .when('/login', {
    templateUrl: 'views/LoginPage.html',
    controller: 'LoginController',
  })
    .when('/signup', {
    templateUrl: 'views/signup.html',
    controller: 'SignupController',
  })
  .when('/admin', {
    templateUrl: 'views/admin.html',
    controller: 'AdminController',
  })

  .when('/tamil', {
    templateUrl: 'views/tamil.html',
    controller: 'TamilController',
  })
  .when('/hindi', {
    templateUrl: 'views/hindi.html',
    controller: 'HindiController',
  })
  .when('/english', {
    templateUrl: 'views/english.html',
    controller: 'EnglishController',
  })
  .when('/showing', {
    templateUrl: 'views/showing.html',
    controller: 'ShowingController',
  })
  .when('/coming', {
    templateUrl: 'views/coming.html',
    controller: 'ComingController',
  })
   .when('/confirm', {
    templateUrl: 'views/confirm.html',
    controller: 'ConfirmController',
  })
   
  .otherwise({
    redirectTo: '/home',
  });
});

// app.run(function ($rootScope, $location, $route, AuthService) {
//   $rootScope.$on('$routeChangeStart',
//     function (event, next, current) {
//       AuthService.getUserStatus()
//       .then(function(){
//         if (next.access.restricted && !AuthService.isLoggedIn()){
//           $location.path('/login');
//           $route.reload();
//         }
//       });
//   });
// });
