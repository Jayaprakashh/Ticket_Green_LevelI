'use strict';

 module.exports = function($scope,$rootScope, $route, $http,$location) {

$scope.bcontact="";
$scope.cg = function(){
    $rootScope.bookingInformation = $scope.bcontact;
    console.log($rootScope.bookingInformation);
     $location.path('/confirm');
      $route.reload();
}

 

//  var getCities = function(username){
//             return $http.get('/city/city')
//                         .then(function(response){
//                            $scope.contactlist = response;
//                         });
//       };
// getCities();

// (function(){
    
//     var userRepoService = function($http){
      
//       var getUsers = function(username){
//             return $http.get('/city/city')
//                         .then(function(response){
//                            return response.data; 
//                         });
//       };
  
//       return {
//           get: getUsers
//       };
        
//     };
    
//     var module = angular.module('movieApp');
//     module.factory('userRepoService', userRepoService);
    
// })();

var refresh = function () {
        $http.get('/city/city').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.contactlist = response;
            $scope.contact = "";
        });
    };

    refresh();



//theatre dropdown

// (function(){
    
//     var userRepoService1 = function($http){
      
//       var getUsers1 = function(username1){
//             return $http.get('/threatre/threatre')
//                         .then(function(response){
//                            return response.data; 
//                         });
//       };
  
//       return {
//           get: getUsers1
//       };
        
//     };
    
//     var module = angular.module('movieApp');
//     module.factory('userRepoService1', userRepoService1);
    
//})();


 var refresht = function () {
        $http.get('/threatre/threatre').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.tlist = response;
            $scope.tcontact = "";
        });
    };
refresht();


//OMDB
//   (function(){
    
//     var getMovieInfo = function($http){
      
//       var getshowinfo = function(showinfo){
//             return $http.get('/movieinfo/movieinfo')
//                         .then(function(response){
//                            return response.data; 
//                         });
//       };
  
//       return {
//           get: getshowinfo
//       };
        
//     };
    
//     var module = angular.module('movieApp');
//     module.factory('getMovieInfo', getMovieInfo);
    
// })();


  var refreshminf = function () {
        $http.get('/movieinfo/movieinfo').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.minflist = response;
            $scope.mcontact = "";
        });
    };
refreshminf();





// showtime crud
 
// (function(){
    
//     var userRepoService2 = function($http){
      
//       var getUsers1 = function(username1){
//             return $http.get('/time/time')
//                         .then(function(response){
//                            return response.data; 
//                         });
//       };
  
//       return {
//           get: getUsers1
//       };
        
//     };
    
//     var module = angular.module('movieApp');
//     module.factory('userRepoService2', userRepoService2);
    
// })();

    var refreshs = function () {
        $http.get('/time/time').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.slist = response;
            $scope.scontact = "";
        });
    };
refreshs();




$scope.getData = function(){
  console.log('Hi Welcome')
  $http.get('http://www.omdbapi.com/?t='+$scope.movieObj.Title+'&plot=short&r=json',{data:"aishu"}).success(function (response) {
      console.log(response);
     // var movieObj={};
      for(var key in response){
      if(key=='Title'|| key=='Year' || key== 'Language' || key== 'Poster' || key== 'Genre' || key== 'Director' || key== 'Actors')
      {
      movieObj[key] = response[key];
      }
     
    console.log(movieObj);

      }
           refresh5();
  });
}



                        var refresh5 = function () {
                            $http.get('/movie/movie').success(function (response) {
                                console.log('READ IS SUCCESSFUL');
                                $scope.movieObj = response;
                                $scope.moviess = "";
                            });
                        };

                    refresh5();





//booking crud Client

var refreshb = function () {
        $http.get('/book/book').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.blist = response;
            $scope.bcontact = "";
        });
    };
refreshb();

    $scope.addbook = function () {
        console.log($scope.bcontact);
        $http.post('/book/book', $scope.bcontact).success(function (response) {
            console.log(response);
            console.log("CREATE IS SUCCESSFUL");
            //refreshb();
            $rootScope.bookingDetails = $scope.bcontact;
            $rootScope.amt1=$scope.amt;
            $location.path('/confirm');
            $route.reload();
        });
    };

     $scope.removebook = function (id) {
        console.log(id);
        $http.delete('/book/book/' + id._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refreshb();
        });
    };

    // $scope.editbook = function (id) {
    //      $http.get('/book/book/' + id._id).success(function (response) {
    //         $scope.bcontact = response[0];
    //     });
    // };

    // $scope.updatebook = function () {
    //     console.log("REACHED UPDATE");
    //     console.log($scope.bcontact._id);
    //     $http.put('/book/book' + $scope.bcontact._id, $scope.bcontact).success(function (response) {
    //         console.log(response);
    //         refreshb();
    //     })
    // }

    $scope.price=function()
    {
       var dd=document.getElementById("a1").value;
       var amt=dd * 100;
       $rootScope.amt=amt;

    }

 }