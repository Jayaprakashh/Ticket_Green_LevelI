
module.exports = function($scope, $rootScope, TodoService) {
  //$scope.cancellation = 'cancellation';
  $scope.bcontact = $rootScope.bookingDetails;
  $scope.amt=$rootScope.amt1;
  console.log($scope.bcontact);
  
};
